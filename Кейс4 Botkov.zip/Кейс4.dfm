object WebModule1: TWebModule1
  Actions = <
    item
      Default = True
      Name = 'DefaultHandler'
      PathInfo = '/'
      OnAction = WebModule1DefaultHandlerAction
    end>
  Height = 288
  Width = 519
  PixelsPerInch = 120
  object FDConnection1: TFDConnection
    Params.Strings = (
      'Server=127.0.0.1'
      'User_Name=root'
      'Password=58257347m'
      'Database=tourism_new'
      'CharacterSet=utf8'
      'DriverID=MySQL')
    LoginPrompt = False
    Left = 464
    Top = 16
  end
  object FDQuery1: TFDQuery
    Connection = FDConnection1
    SQL.Strings = (
      'SELECT '
      '  '#1079'.id'#1047#1072#1082#1072#1079#1099', '
      '  '#1082'.'#1048#1084#1103', '
      '  '#1082'.'#1060#1072#1084#1080#1083#1080#1103', '
      '  '#1086'.'#1053#1072#1079#1074#1072#1085#1080#1077' AS '#1054#1090#1077#1083#1100', '
      '  '#1089'.'#1057#1090#1088#1072#1085#1072', '
      '  '#1101'.'#1053#1072#1079#1074#1072#1085#1080#1077' AS '#1069#1082#1089#1082#1091#1088#1089#1080#1103', '
      '  '#1101'.'#1062#1077#1085#1072','#11
      '  '#1079'.order_date'
      'FROM '#1047#1072#1082#1072#1079#1099' '#1079
      'JOIN '#1050#1083#1080#1077#1085#1090#1099' '#1082' ON '#1079'.id'#1050#1083#1080#1077#1085#1090#1099' = '#1082'.id'#1050#1083#1080#1077#1085#1090#1099
      'JOIN '#1054#1090#1077#1083#1080' '#1086' ON '#1079'.id'#1054#1090#1077#1083#1080' = '#1086'.id'#1054#1090#1077#1083#1080
      'JOIN '#1057#1090#1088#1072#1085#1099' '#1089' ON '#1086'.id'#1057#1090#1088#1072#1085#1099' = '#1089'.id'#1057#1090#1088#1072#1085#1099
      'JOIN '#1069#1082#1089#1082#1091#1088#1089#1089#1080#1080' '#1101' ON '#1079'.id'#1069#1082#1089#1082#1091#1088#1089#1089#1080#1080' = '#1101'.id'#1069#1082#1089#1082#1091#1088#1089#1089#1080#1080)
    Left = 392
    Top = 160
  end
  object FDPhysMySQLDriverLink1: TFDPhysMySQLDriverLink
    VendorLib = 'C:\Users\botko\OneDrive\Desktop\'#1050#1077#1081#1089'4\libmysql.dll'
    Left = 248
    Top = 104
  end
  object PageProducer1: TPageProducer
    HTMLDoc.Strings = (
      '<html>'
      '<head>'
      '  <meta charset="UTF-8">'
      '  <title>'#1050#1077#1081#1089' '#8470'4: '#1058#1091#1088#1092#1080#1088#1084#1072'</title>'
      '  <style>'
      '    h1 { color: #8B0000; font-family: Arial, sans-serif; }'
      
        '    table { width: 100%; border-collapse: collapse; font-family:' +
        ' Arial, sans-serif; }'
      '    th { background-color: #f2f2f2; }'
      '  </style>'
      '</head>'
      '<body>'
      '  <h1>'#1057#1087#1080#1089#1086#1082' '#1079#1072#1082#1072#1079#1086#1074' ('#1058#1077#1089#1090#1050#1077#1081#1089'4)</h1>'
      '  <table border="1" cellpadding="8">'
      '    <tr>'
      '      <th>'#8470'</th>'
      '      <th>'#1050#1083#1080#1077#1085#1090'</th>'
      '      <th>'#1054#1090#1077#1083#1100'</th>'
      '      <th>'#1057#1090#1088#1072#1085#1072'</th>'
      '      <th>'#1069#1082#1089#1082#1091#1088#1089#1080#1103'</th>'
      '      <th>'#1062#1077#1085#1072'</th> <th>'#1044#1072#1090#1072' '#1079#1072#1082#1072#1079#1072'</th>'
      '    </tr>'
      '    <#ORDER_LIST>'
      '  </table>'
      '</body>'
      '</html>')
    OnHTMLTag = PageProducer1HTMLTag
    Left = 56
    Top = 72
  end
end
