unit ����4;

interface

uses
  System.SysUtils, System.Classes, Web.HTTPApp, FireDAC.Stan.Intf,
  FireDAC.Stan.Option, FireDAC.Stan.Error, FireDAC.UI.Intf, FireDAC.Phys.Intf,
  FireDAC.Stan.Def, FireDAC.Stan.Pool, FireDAC.Stan.Async, FireDAC.Phys,
  FireDAC.Phys.MySQL, FireDAC.Phys.MySQLDef, FireDAC.ConsoleUI.Wait,
  FireDAC.Stan.Param, FireDAC.DatS, FireDAC.DApt.Intf, FireDAC.DApt,
  Web.HTTPProd, Data.DB, FireDAC.Comp.DataSet, FireDAC.Comp.Client;

type
  TWebModule1 = class(TWebModule)
    FDConnection1: TFDConnection;
    FDQuery1: TFDQuery;
    FDPhysMySQLDriverLink1: TFDPhysMySQLDriverLink;
    PageProducer1: TPageProducer;
    procedure WebModule1DefaultHandlerAction(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
    procedure PageProducer1HTMLTag(Sender: TObject; Tag: TTag;
      const TagString: string; TagParams: TStrings; var ReplaceText: string);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WebModuleClass: TComponentClass = TWebModule1;

implementation

{%CLASSGROUP 'System.Classes.TPersistent'}

{$R *.dfm}


procedure TWebModule1.WebModule1DefaultHandlerAction(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
begin
  Response.Content := PageProducer1.Content;
end;

procedure TWebModule1.PageProducer1HTMLTag(Sender: TObject; Tag: TTag;
  const TagString: string; TagParams: TStrings; var ReplaceText: string);
var
  S: string;
begin
  if TagString = 'ORDER_LIST' then
  begin
    try
      FDQuery1.Close;
      FDQuery1.Open;
      S := '';
      while not FDQuery1.Eof do
    begin
      S := S + '<tr>' +
        '<td>' + FDQuery1.FieldByName('id������').AsString + '</td>' +
        '<td>' + FDQuery1.FieldByName('���').AsString + ' ' + FDQuery1.FieldByName('�������').AsString + '</td>' +
        '<td>' + FDQuery1.FieldByName('�����').AsString + '</td>' +
        '<td>' + FDQuery1.FieldByName('������').AsString + '</td>' +
        '<td>' + FDQuery1.FieldByName('���������').AsString + '</td>' +
        '<td>' + FDQuery1.FieldByName('����').AsString + ' �</td>' +
        '<td>' + FDQuery1.FieldByName('order_date').AsString + '</td>' +
        '</tr>';
      FDQuery1.Next;
    end;
      ReplaceText := S;
    except
      on E: Exception do
        ReplaceText := '<tr><td colspan="6">������ ��: ' + E.Message + '</td></tr>';
    end;
  end;
end;

end.
